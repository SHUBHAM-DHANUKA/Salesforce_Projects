import { LightningElement, track, wire } from 'lwc';
import getAccountList from '@salesforce/apex/stringFilteration.stringFilterationMethod';
const columns = [
    { label: 'Account Name', fieldName: 'Name' },
    { label: 'Account Number', fieldName: 'AccountNumber' },
    { label: 'Phone', fieldName: 'Phone', type: 'phone' },
];
export default class String_Filteration extends LightningElement {
    columns = columns;
    data = [];
    // @wire(getAccountList, { fields: [searchType:`$this.`, str:`$`] })
    // AccountHandler({ data, error }) {
    //     if (data) {
    //         console.log(data)
    //         //this.fullTableData = data
    //         //this.filteredData = data
    //     }
    //     if (error) {
    //         console.log(error)
    //     }
    // }
    final_string = "";
    timer;
    @track areDetailsVisible = false;
    @track searchType = "ALL";
    @track searchKey = "";

    final_account_list;
    get options() {
        return [
            { label: 'ALL', value: 'ALL' },
            { label: 'Account Number', value: 'Account Number' },
            { label: 'Account Name', value: 'Account Name' },
            { label: 'Account Contact', value: 'Account Contact' },

        ];
    }

    handleChange(event) {
        this.searchType = event.target.value;
    }

    typedQuery(event) {
        this.final_string = event.target.value;
        window.clearTimeout(this.timer);
        if (this.final_string != null) {
            this.timer = window.setTimeout(() => {
                this.datafectcher(this.final_string);
            }, 1000);
        }

    }
    datafectcher(string) {
        this.searchKey = string;
        console.log('type==>' + this.searchType + '  ' + 'searchkey==> ' + this.searchKey);
        if (this.searchType != null && this.searchKey != null) {
            //do something
            getAccountList({ searchType: this.searchType, str: this.searchKey }).then((result) => {
                this.final_account_list = result;
                this.error = undefined;
                console.log("result is " + JSON.stringify(this.final_account_list));
                this.data = this.final_account_list;
                this.areDetailsVisible = true;

            }).catch((error) => {

                this.error = error;
                this.final_account_list = undefined;
                console.error(error);
            })

        }


    }
}
