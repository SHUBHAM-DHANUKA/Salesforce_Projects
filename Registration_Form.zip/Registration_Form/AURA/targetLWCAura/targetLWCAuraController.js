({
    myAction: function (component, event, helper) {

    },
    init: function (cmp, evt, helper) {
        var myPageRef = cmp.get("v.pageReference");
        cmp.set("v.registration", myPageRef.state.c__registration);
    }
})
