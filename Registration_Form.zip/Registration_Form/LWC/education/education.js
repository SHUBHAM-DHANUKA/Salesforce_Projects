import { LightningElement, track, wire, api } from 'lwc';
import education from '@salesforce/apex/Education.Education_method';
import { NavigationMixin } from 'lightning/navigation';
import State from '@salesforce/schema/Lead.State';
export default class Education extends NavigationMixin(LightningElement) {
    @track Canditate_1oth_pass__c;
    @track Canditate_12th_pass__c;
    @track Canditate_Graduate__c;
    @api Registration_form_detail__c;

    handleClick(event) {
        //alert("this is clicked");
        var input = this.template.querySelectorAll("lightning-input");
        input.forEach(function (element) {
            if (element.name == "input1")
                this.Canditate_1oth_pass__c = element.checked;
            else if (element.name == "input2")
                this.Canditate_12th_pass__c = element.checked;
            else if (element.name == "input3")
                this.Canditate_Graduate__c = element.value;
        }, this);
        //this.Registration_form_detail__c = 'a001y000002YbjjAAC';

        console.log(this.Canditate_1oth_pass__c);
        console.log(this.Canditate_12th_pass__c);
        console.log(this.Canditate_Graduate__c);
        console.log("this.Registration_form_detail__c==>" + this.Registration_form_detail__c);
        event.preventDefault();
        education({ tenth: this.Canditate_1oth_pass__c, twelve: this.Canditate_12th_pass__c, graduation: this.Canditate_Graduate__c, regId: this.Registration_form_detail__c }).then((result) => {
            //console.log("result is " + JSON.stringify(result));
            //alert("Here we go!!" + JSON.stringify(result));
            /*var definition = {
               componentDef: 'c:experience',
               attributes: {
                   Registration_form_detail__c: this.Registration_form_detail__c
               }
           }
           this[NavigationMixin.Navigate]({
               type: 'standard__webPage',
               attributes: {
                   url: 'one/one.app#' + btoa(JSON.stringify(definition))
               }
           });*/

            //event.preventDefault();
            this[NavigationMixin.Navigate]({
                type: 'standard__component',
                attributes: {
                    componentName: 'c__targetLWCAura'//aura component name
                },
                state: {
                    c__registration: this.Registration_form_detail__c
                }
            });


        }).catch((error) => {
            console.error(error);
        })


    }
}
