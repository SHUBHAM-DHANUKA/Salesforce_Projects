import { LightningElement, track, api } from 'lwc';
import experience from '@salesforce/apex/Experience.Experience_method';
import { NavigationMixin } from 'lightning/navigation';
export default class Experience extends NavigationMixin(LightningElement) {
    @track Company_Name__c;
    @track Yr_of_experience__c = 0.0;
    @api Registration_form_detail__c;

    handleClick() {
        var input = this.template.querySelectorAll("lightning-input");
        input.forEach(function (element) {
            if (element.name == "input1")
                this.Company_Name__c = element.value;
            else if (element.name == "input2") {
                if (element.value == null || element.value == undefined || element.value == '') {
                    this.Yr_of_experience__c = 0.00;
                }
                else { this.Yr_of_experience__c = element.value; }

            }
        }, this);
        //this.Registration_form_detail__c = 'a001y000002YbBbAAK';

        console.log(this.Company_Name__c);
        console.log(this.Yr_of_experience__c);
        console.log(this.Registration_form_detail__c);

        experience({ companyName: this.Company_Name__c, yoe: this.Yr_of_experience__c, regId: this.Registration_form_detail__c }).then((result) => {
            //console.log("result is " + JSON.stringify(result));
            //alert("Here we go!!" + JSON.stringify(result));
            if (result == 'Success') {
                alert("Congratulation !! your data has been submitted !!");
            }
        }).catch((error) => {
            console.error(error);
        })
    }

}