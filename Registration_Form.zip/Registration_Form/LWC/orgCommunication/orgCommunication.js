import { LightningElement } from 'lwc';

export default class OrgCommunication extends LightningElement { }