import { LightningElement, track, wire } from 'lwc';
import registration from '@salesforce/apex/Registration.Registration_method';
import { NavigationMixin } from 'lightning/navigation';
export default class Registration_Form extends NavigationMixin(LightningElement) {

    @track canditateName = ""
    @track canditateEmail = ""
    @track canditatePhone = ""

    registrationId;

    handleClick() {
        //alert("here we go!!");
        var input = this.template.querySelectorAll("lightning-input");
        input.forEach(function (element) {
            if (element.name == "input1")
                this.canditateName = element.value;
            else if (element.name == "input2")
                this.canditateEmail = element.value;
            else if (element.name == "input3")
                this.canditatePhone = element.value;
        }, this);
        console.log(this.canditateName);


        registration({ Name: this.canditateName, Email: this.canditateEmail, Phone: this.canditatePhone }).then((result) => {
            console.log("result in string " + JSON.stringify(result));
            console.log("result without string " + result);
            this.registrationId = JSON.stringify(result);
            //alert("Here we go!!" + this.registrationId);

            var definition = {
                componentDef: 'c:education',
                attributes: {
                    Registration_form_detail__c: result
                }
            }
            console.log("this.registrationId==>" + this.registrationId);
            this[NavigationMixin.Navigate]({
                type: 'standard__webPage',
                attributes: {
                    url: 'one/one.app#' + btoa(JSON.stringify(definition))
                }
            });

        }).catch((error) => {
            console.error(error);
        })



    }

}